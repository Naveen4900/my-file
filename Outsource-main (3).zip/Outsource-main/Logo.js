var LogoList = {
    logos: {
              EmptyLogo: [   {varriantname:'emptylogo',logourl:require('../assets/noimage.png'),filename:'noimage.png'}], 
              Birthday : [  
                             {varriantname:'birthdaycakecap',logourl:require('../assets/birthday-party-1.png'),filename:'birthday-party-1.png'},
                             {varriantname:'birthdayletters',logourl:require('../assets/birthday-1.png'),filename:'birthday-1.png'},
                             {varriantname:'birthdaycakeblue',logourl:require('../assets/birthday-2.png'),filename:'birthday-2.png'},
                             {varriantname:'birthdaycakefruit',logourl:require('../assets/birthday-3.png'),filename:'birthday-3.png'},
                             {varriantname:'birthdayletters',logourl:require('../assets/birthday-4.png'),filename:'birthday-4.png'}
                         ],
                Movies :  [  {varriantname:'moviepopcorn' , logourl:require('../assets/entertainment-movies-1.png'),filename:'entertainment-movies-1.png'} ],
                Travel :  [  
                              {varriantname:'beachumbrella' , logourl:require('../assets/travel-beach-1.png'),filename:'travel-beach-1.png'},
                              {varriantname:'beachocean' , logourl:require('../assets/travel-beach-3.png'),filename:'travel-beach-3.png'},
                              {varriantname:'beachall' , logourl:require('../assets/travel-beach-4.png'),filename:'travel-beach-4.png'}
                          ],
         Celebrations :   [  
                             {varriantname:'baloonsred' , logourl:require('../assets/celebrations-balloons-1.png'), filename: 'celebrations-balloons-1.png'},
                          ],
            Hindu     :   [
                             {varriantname:'goddurga' , logourl:require('../assets/hindu-durga-1.png'), filename: 'hindu-durga-1.png'},
                             {varriantname:'goddurga' , logourl:require('../assets/hindu-durga-2.png'), filename: 'hindu-durga-2.png'},
                             {varriantname:'godganesh' , logourl:require('../assets/hindu-ganesh-1.png'), filename: 'hindu-ganesh-1.png'},
                             {varriantname:'godkrishna' , logourl:require('../assets/hindu-krishna-little-1.png'), filename: 'hindu-krishna-little-1.png'},
                             {varriantname:'godlakshmi' , logourl:require('../assets/hindu-lakshmi.png'), filename: 'hindu-lakshmi.png'},
                             {varriantname:'festivalpongal' , logourl:require('../assets/hindu-pongal-1.png'), filename: 'hindu-pongal-1.png'},
                             {varriantname:'festivalpooja' , logourl:require('../assets/hindu-pooja-1.png'), filename: 'hindu-pooja-1.png'},
                          ]
            }
   }


var LogoMapList = {
'EmptyLogo': LogoList.logos.EmptyLogo,
'Birthday': LogoList.logos.Birthday,
'Movies': LogoList.logos.Movies,
'Travel': LogoList.logos.Travel,
'Celebrations': LogoList.logos.Celebrations,
'Hindu': LogoList.logos.Hindu
};

export default LogoMapList;